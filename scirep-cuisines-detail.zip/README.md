* `map.txt`: the mapping for collapsing regions. 
* `epic_recipes.txt`: recipes from epicurious. the first column is the cuisine. 
* `allr_recipes.txt`: recipes from allrecipes.com
* `menu_recipes.txt`: recipes from menupan.com

